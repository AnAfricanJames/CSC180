import java.io.*;

public class ItemSerializer
{
	public static void main(String[] args) throws Exception {
		Item i = new Item(1, "123456789012", "Radio Controlled Helicopter", 5, 4.99, 39.99);
		OutputStream o = new FileOutputStream("C:\\tmp\\item.ser");
		ObjectOutputStream oos = new ObjectOutputStream(o);
		oos.writeObject(i);
		oos.close();
		o.close();
	}
	
	public static void main(String[] args) throws Exception {
		InputStream i = new FileInputStream("C:\\tmp\\item.ser");
		ObjectInputStream ois = new ObjectInputStream(i);
		Item item = (Item)ois.readObject();
		ois.close();
		System.out.println(item.getUPC() + " " + item.getTitle());
	}
}






