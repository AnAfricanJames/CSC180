import java.io.Serializable;

public class Item implements Serializable
{
	public Item() {
	}
	
	public Item(int id, String upc, String title, int qty, double cost, double retail) {
		this.setID(id);
		this.setUPC(upc);
		this.setTitle(title);
		this.setQuantity(qty);
		this.setCost(cost);
		this.setRetail(retail);
	}
	
	private int id;
	private String upc;
	private String title;
	private int quantity;
	private double cost;
	private double retail;
	
	public int getID() {
		return this.id;
	}
	
	public String getUPC() {
		return this.upc;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public int getQuantity() {
		return this.quantity;
	}
	
	public double getCost() {
		return this.cost;
	}
	
	public double getRetail() {
		return this.retail;
	}
	
	public void setID(int id) {
		this.id = id;
	}
	
	public void setUPC(String upc) {
		this.upc = upc;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setQuantity(int qty) {
		this.quantity = qty;
	}
	
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	public void setRetail(double retail) {
		this.retail = retail;
	}
}